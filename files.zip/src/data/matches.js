// Dummy data. Replace with real API calls in production.
export const matches = [
  {
    id: 1,
    channel: "football",
    home: "Team A",
    away: "Team B",
    score: [1, 0],
    status: "LIVE",
    time: 67,
    streamUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    poster: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 2,
    channel: "football",
    home: "Team C",
    away: "Team D",
    score: [0, 0],
    status: "UPCOMING",
    time: "2025-06-14 18:00",
    streamUrl: null,
    poster: null
  }
];