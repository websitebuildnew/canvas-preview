// You can add more channels/sports here!
export const channels = [
  {
    id: "football",
    name: "Football Live",
    description: "Watch live football matches, highlights, and more.",
    youtube: "https://youtube.com/@90_plusminutes/",
    instagram: "http://instagram.com/90.plus.minutes/",
    twitter: "https://twitter.com/90_plusminutes/",
    facebook: "https://www.facebook.com/90plusminuts/",
    promo: "Subscribe to our YouTube for exclusive football highlights!",
    logo: "https://img.icons8.com/color/96/football2.png"
  },
  // Example for future sports:
  // {
  //   id: "basketball",
  //   name: "Basketball Live",
  //   ...
  // }
];