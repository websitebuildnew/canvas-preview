import React, { createContext, useContext, useState, useEffect } from "react";
import { api } from "../services/api";
import { logout as doLogout } from "../services/auth";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // On mount, try to fetch user info with token
  useEffect(() => {
    async function getUser() {
      try {
        const res = await api.get("/auth/me", {
          headers: { ...getAuthHeaders() },
        });
        setUser(res.data);
      } catch {
        setUser(null);
      }
      setLoading(false);
    }
    getUser();
  }, []);

  function logout() {
    doLogout();
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, setUser, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);

// Helper
function getAuthHeaders() {
  const token = localStorage.getItem("token");
  return token ? { Authorization: `Bearer ${token}` } : {};
}