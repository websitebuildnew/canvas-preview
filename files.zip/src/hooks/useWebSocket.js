import { useEffect, useRef, useState } from "react";

export default function useWebSocket(url, onMessage) {
  const ws = useRef(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    ws.current = new window.WebSocket(url);

    ws.current.onopen = () => setConnected(true);
    ws.current.onclose = () => setConnected(false);
    ws.current.onerror = () => setConnected(false);

    ws.current.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data);
        onMessage && onMessage(msg);
      } catch {}
    };

    return () => ws.current && ws.current.close();
    // eslint-disable-next-line
  }, [url]);

  function send(obj) {
    if (ws.current && ws.current.readyState === 1) {
      ws.current.send(JSON.stringify(obj));
    }
  }

  return { send, connected };
}