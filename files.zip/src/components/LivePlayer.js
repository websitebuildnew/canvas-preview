import React, { useRef, useEffect, useState } from "react";
import useWebSocket from "../hooks/useWebSocket";

const WS_URL = "ws://localhost:4001"; // adjust for prod

export default function LivePlayer() {
  const [match, setMatch] = useState(null);
  const canvasRef = useRef(null);

  // Subscribe for real-time match data
  useWebSocket(WS_URL, msg => {
    if (msg.type === "MATCH_UPDATE") setMatch(msg.payload);
  });

  // Draw overlay on match updates
  useEffect(() => {
    if (!match || !canvasRef.current) return;
    const ctx = canvasRef.current.getContext("2d");
    ctx.clearRect(0, 0, 640, 40);
    ctx.font = "bold 22px Arial";
    ctx.fillStyle = "#10b981";
    ctx.fillText(
      `${match.home} ${match.score[0]} - ${match.score[1]} ${match.away} | ${match.status} | ${match.time}'`,
      15, 30
    );
  }, [match]);

  return (
    <div className="relative rounded shadow overflow-hidden bg-black">
      <video
        src="https://www.w3schools.com/html/mov_bbb.mp4"
        controls
        autoPlay
        className="w-full aspect-video"
        poster="https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=800&q=80"
      />
      <canvas
        ref={canvasRef}
        width={640}
        height={40}
        className="absolute top-2 left-2 bg-transparent pointer-events-none"
        style={{ zIndex: 2 }}
      />
      <div className="absolute top-2 right-2 bg-green-600 text-white px-2 py-1 rounded">
        {match?.status || "WAIT"}
      </div>
    </div>
  );
}