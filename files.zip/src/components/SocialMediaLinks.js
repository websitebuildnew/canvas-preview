import React from "react";

export default function SocialMediaLinks({ channel }) {
  if (!channel) return null;
  const links = [
    { url: channel.youtube, label: "YouTube", icon: "📺" },
    { url: channel.instagram, label: "Instagram", icon: "📸" },
    { url: channel.twitter, label: "Twitter", icon: "🐦" },
    { url: channel.facebook, label: "Facebook", icon: "📘" }
  ];
  return (
    <div className="mb-6 flex flex-wrap gap-4 items-center">
      <span className="font-semibold text-gray-600">Follow us:</span>
      {links.map(l => l.url && (
        <a
          key={l.label}
          href={l.url}
          target="_blank"
          rel="noopener noreferrer"
          className="hover:text-green-700 transition font-semibold"
        >
          <span className="mr-1">{l.icon}</span>{l.label}
        </a>
      ))}
    </div>
  );
}