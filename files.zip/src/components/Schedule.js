import React from "react";

export default function Schedule({ matches }) {
  if (!matches.length) return null;
  return (
    <div className="bg-white rounded shadow p-4">
      <h2 className="text-lg font-bold mb-2">Upcoming Matches</h2>
      <ul className="divide-y">
        {matches.map(m => (
          <li key={m.id} className="py-2 flex justify-between items-center">
            <span>
              {m.home} <span className="font-bold">vs</span> {m.away}
            </span>
            <span className="text-sm text-gray-500">{m.time}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}