import React, { useState } from "react";
import useWebSocket from "../hooks/useWebSocket";

const WS_URL = "ws://localhost:4001";

export default function AdminLiveControl() {
  const { send, connected } = useWebSocket(WS_URL);
  const [home, setHome] = useState("Team A");
  const [away, setAway] = useState("Team B");
  const [score, setScore] = useState([1, 0]);
  const [time, setTime] = useState(45);

  function updateMatch(e) {
    e.preventDefault();
    send({
      type: "ADMIN_UPDATE",
      payload: {
        home, away,
        score: [parseInt(score[0]), parseInt(score[1])],
        time: parseInt(time),
        status: "LIVE"
      }
    });
  }

  return (
    <form onSubmit={updateMatch} className="bg-white p-4 rounded shadow mb-4">
      <h3 className="font-bold mb-2">Admin Live Control {connected ? "🟢" : "🔴"}</h3>
      <input value={home} onChange={e => setHome(e.target.value)} className="border mr-2 px-2" />
      <input value={away} onChange={e => setAway(e.target.value)} className="border mr-2 px-2" />
      <input value={score[0]} onChange={e => setScore([e.target.value, score[1]])} type="number" min="0" className="w-12 border mx-1 px-1" />
      -
      <input value={score[1]} onChange={e => setScore([score[0], e.target.value])} type="number" min="0" className="w-12 border mx-1 px-1" />
      <input value={time} onChange={e => setTime(e.target.value)} type="number" min="0" max="120" className="w-14 border mx-2 px-1" />'
      <button type="submit" className="bg-green-700 text-white px-3 py-1 rounded ml-2">Send Update</button>
    </form>
  );
}