import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "../services/api";
import LivePlayer from "../components/LivePlayer";
import Schedule from "../components/Schedule";
import SocialMediaLinks from "../components/SocialMediaLinks";

export default function ChannelPage() {
  const { id } = useParams();
  const [channel, setChannel] = useState(null);
  const [live, setLive] = useState(null);
  const [upcoming, setUpcoming] = useState([]);

  useEffect(() => {
    api.get(`/channels/${id}`).then(res => setChannel(res.data));
    api.get(`/matches?channel=${id}&status=LIVE`).then(res => setLive(res.data[0]));
    api.get(`/matches?channel=${id}&status=UPCOMING`).then(res => setUpcoming(res.data));
  }, [id]);

  if (!channel) return <div className="p-8 text-red-700 font-bold">Channel not found</div>;

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      <div className="flex items-center gap-4 mb-4">
        <img src={channel.logo} alt="" className="w-12 h-12"/>
        <h1 className="text-2xl font-bold">{channel.name}</h1>
      </div>
      <p className="mb-4">{channel.promo}</p>
      <SocialMediaLinks channel={channel} />
      {live ? (
        <div className="mb-8">
          <h2 className="text-lg font-bold mb-2">Live Match</h2>
          <LivePlayer match={live} />
        </div>
      ) : (
        <div className="mb-8 p-6 bg-yellow-100 rounded-lg text-yellow-800 font-semibold">
          No live match currently. Check upcoming matches below!
        </div>
      )}
      <Schedule matches={upcoming} />
    </div>
  );
}