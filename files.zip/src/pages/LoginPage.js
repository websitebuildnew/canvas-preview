import React, { useState } from "react";
import { login } from "../services/auth";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const { setUser } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setErr("");
    try {
      const user = await login(email, password);
      setUser(user);
      navigate("/");
    } catch (error) {
      setErr("Invalid credentials");
    }
  }

  return (
    <div className="max-w-md mx-auto mt-16 bg-white p-6 rounded shadow">
      <h2 className="text-2xl font-bold mb-4">Sign In</h2>
      {err && <div className="mb-3 text-red-600">{err}</div>}
      <form onSubmit={handleSubmit}>
        <input
          className="block w-full mb-2 border px-3 py-2 rounded"
          type="email"
          placeholder="Email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          required
        />
        <input
          className="block w-full mb-4 border px-3 py-2 rounded"
          type="password"
          placeholder="Password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          required
        />
        <button className="bg-green-700 text-white px-4 py-2 rounded w-full">Sign In</button>
      </form>
    </div>
  );
}