import React from "react";
import { channels } from "../data/channels";
import { Link } from "react-router-dom";

export default function HomePage() {
  return (
    <div className="max-w-4xl mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold mb-6">Welcome to Sports Channel</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {channels.map(ch => (
          <Link
            to={`/channel/${ch.id}`}
            key={ch.id}
            className="bg-white rounded shadow p-6 flex flex-col items-center hover:shadow-lg transition"
          >
            <img src={ch.logo} alt={ch.name} className="w-16 h-16 mb-3"/>
            <span className="text-xl font-semibold">{ch.name}</span>
            <p className="text-gray-600 text-center mt-2">{ch.description}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}