import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import AdminMatches from "./admin/AdminMatches";
import AdminChannels from "./admin/AdminChannels";
import { useAuth } from "../context/AuthContext";

export default function AdminPage() {
  const { logout, user } = useAuth();
  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      <div className="flex justify-between mb-6">
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <div>
          <span className="mr-3">{user?.email}</span>
          <button onClick={logout} className="bg-red-500 text-white px-2 py-1 rounded">Logout</button>
        </div>
      </div>
      <nav className="mb-6 flex gap-4">
        <Link to="matches" className="text-green-700 font-bold">Matches</Link>
        <Link to="channels" className="text-green-700 font-bold">Channels</Link>
      </nav>
      <Routes>
        <Route path="matches" element={<AdminMatches />} />
        <Route path="channels" element={<AdminChannels />} />
        <Route path="*" element={<div>Select a section</div>} />
      </Routes>
    </div>
  );
}