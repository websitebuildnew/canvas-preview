import React, { useEffect, useState } from "react";
import { api, getAuthHeaders } from "../../services/api";

export default function AdminMatches() {
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/matches", { headers: getAuthHeaders() })
      .then(res => setMatches(res.data))
      .finally(() => setLoading(false));
  }, []);

  // You can add more CRUD operations here

  if (loading) return <div>Loading...</div>;

  return (
    <div>
      <h2 className="text-lg font-bold mb-3">Manage Matches</h2>
      <table className="w-full">
        <thead>
          <tr><th>ID</th><th>Teams</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
          {matches.map(m => (
            <tr key={m.id}>
              <td>{m.id}</td>
              <td>{m.home} vs {m.away}</td>
              <td>{m.status}</td>
              <td>
                {/* Edit/Delete/GoLive buttons */}
                <button className="text-blue-700 mr-2">Edit</button>
                <button className="text-red-600">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {/* Add match form/modal, etc. */}
    </div>
  );
}