import React, { useEffect, useState } from "react";
import { api, getAuthHeaders } from "../../services/api";
export default function AdminChannels() {
  const [channels, setChannels] = useState([]);
  useEffect(() => {
    api.get("/channels", { headers: getAuthHeaders() })
      .then(res => setChannels(res.data));
  }, []);
  return (
    <div>
      <h2 className="text-lg font-bold mb-3">Manage Channels</h2>
      <ul>
        {channels.map(c => (
          <li key={c.id} className="mb-2">
            <span className="font-semibold">{c.name}</span>
          </li>
        ))}
      </ul>
      {/* Add/Edit/Delete channel logic here */}
    </div>
  );
}