import { api, setToken, clearToken } from "./api";

export async function login(email, password) {
  const res = await api.post("/auth/login", { email, password });
  setToken(res.data.token);
  return res.data.user;
}

export async function register(email, password) {
  const res = await api.post("/auth/register", { email, password });
  setToken(res.data.token);
  return res.data.user;
}

export function logout() {
  clearToken();
}