const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 4001 });

let matchState = {
  home: "Team A",
  away: "Team B",
  score: [1, 0],
  time: 45,
  status: "LIVE"
};

wss.on('connection', ws => {
  // Send initial state
  ws.send(JSON.stringify({ type: "MATCH_UPDATE", payload: matchState }));

  ws.on('message', message => {
    // For demo: allow admin to send JSON updates
    try {
      const { type, payload } = JSON.parse(message);
      if (type === "ADMIN_UPDATE") {
        matchState = { ...matchState, ...payload };
        // Broadcast to all clients
        wss.clients.forEach(client => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ type: "MATCH_UPDATE", payload: matchState }));
          }
        });
      }
    } catch (e) {}
  });
});

console.log("WebSocket server running on ws://localhost:4001");