import React, { useState, useEffect } from "react";
import { login, getCurrentUser, logout } from "./auth";
import { apiGet } from "./api";
import LivePlayer from "./components/LivePlayer";
import AdminPanel from "./components/AdminPanel";

export default function App() {
  const [user, setUser] = useState(null);
  const [matches, setMatches] = useState([]);
  const [selected, setSelected] = useState(null);
  const [authErr, setAuthErr] = useState("");

  useEffect(() => {
    getCurrentUser().then(u => setUser(u));
    apiGet("/matches").then(setMatches);
  }, []);

  function handleLogin(e) {
    e.preventDefault();
    const email = e.target.email.value;
    const password = e.target.password.value;
    login(email, password)
      .then(user => setUser(user))
      .catch(err => setAuthErr(err.message));
  }

  return (
    <div className="max-w-3xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold mb-8">Sports Channel Live</h1>
      {!user && (
        <form onSubmit={handleLogin} className="mb-8 bg-white p-4 rounded shadow">
          <h2 className="mb-2 font-bold">Login</h2>
          {authErr && <div className="mb-2 text-red-600">{authErr}</div>}
          <input name="email" placeholder="Email" className="border rounded px-2 py-1 mr-2" />
          <input name="password" type="password" placeholder="Password" className="border rounded px-2 py-1 mr-2" />
          <button className="bg-green-700 text-white px-3 py-1 rounded">Sign In</button>
        </form>
      )}
      {user && (
        <div className="mb-6">
          Signed in as <b>{user.email}</b>{" "}
          <button onClick={() => { logout(); setUser(null); }} className="text-red-700 ml-2">Logout</button>
        </div>
      )}
      <div className="mb-8">
        <h2 className="mb-2 font-bold">Live Matches</h2>
        <ul>
          {matches.filter(m => m.status === "LIVE").map(m => (
            <li key={m.id} className="mb-2">
              <button onClick={() => setSelected(m)} className="text-green-700 underline">
                {m.home} vs {m.away}
              </button>
            </li>
          ))}
        </ul>
      </div>
      {selected && (
        <LivePlayer
          matchId={selected.id}
          match={selected}
          onRealtime={data => setSelected(data)}
        />
      )}
      {user?.isAdmin && <AdminPanel />}
    </div>
  );
}