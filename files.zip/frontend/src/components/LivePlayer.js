import React, { useRef, useEffect } from "react";
import useWebSocket from "../hooks/useWebSocket";

export default function LivePlayer({ matchId, match, onRealtime }) {
  const canvasRef = useRef(null);

  useWebSocket("ws://localhost:4000", msg => {
    if (msg.type === "MATCH_UPDATE" && msg.payload.id === matchId) {
      onRealtime && onRealtime(msg.payload);
    }
  });

  useEffect(() => {
    if (!canvasRef.current || !match) return;
    const ctx = canvasRef.current.getContext("2d");
    ctx.clearRect(0, 0, 640, 40);
    ctx.font = "bold 22px Arial";
    ctx.fillStyle = "#10b981";
    ctx.fillText(
      `${match.home} ${match.score[0]} - ${match.score[1]} ${match.away} | ${match.status} | ${match.time}'`,
      15, 30
    );
  }, [match]);

  if (!match) return null;

  return (
    <div className="relative rounded shadow overflow-hidden bg-black mb-6">
      <video
        src={match.streamUrl}
        controls
        autoPlay
        className="w-full aspect-video"
        poster={match.poster}
      />
      <canvas
        ref={canvasRef}
        width={640}
        height={40}
        className="absolute top-2 left-2 bg-transparent pointer-events-none"
        style={{ zIndex: 2 }}
      />
      <div className="absolute top-2 right-2 bg-green-600 text-white px-2 py-1 rounded">
        {match.status}
      </div>
    </div>
  );
}