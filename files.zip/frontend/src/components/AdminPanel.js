import React, { useState, useEffect } from "react";
import { apiGet, apiPut, apiPost, apiDelete } from "../api";
import useWebSocket from "../hooks/useWebSocket";

export default function AdminPanel() {
  const [matches, setMatches] = useState([]);
  const [editing, setEditing] = useState(null);

  // Fetch all matches
  useEffect(() => {
    apiGet("/matches").then(setMatches);
  }, []);

  // Real-time updates
  useWebSocket("ws://localhost:4000", msg => {
    if (msg.type === "MATCH_UPDATE") {
      setMatches(ms =>
        ms.map(m => (m.id === msg.payload.id ? msg.payload : m))
      );
    }
  });

  // Edit score/time
  function startEdit(match) {
    setEditing({ ...match });
  }
  function saveEdit() {
    apiPut(`/matches/${editing.id}`, editing).then(updated => {
      setMatches(ms => ms.map(m => (m.id === updated.id ? updated : m)));
      setEditing(null);
    });
  }
  function remove(id) {
    apiDelete(`/matches/${id}`).then(() =>
      setMatches(ms => ms.filter(m => m.id !== id))
    );
  }
  function addMatch() {
    apiPost("/matches", {
      home: "New Home",
      away: "New Away",
      score: [0, 0],
      time: 0,
      status: "UPCOMING",
      streamUrl: "",
      poster: ""
    }).then(m => setMatches(ms => [...ms, m]));
  }

  return (
    <div>
      <h2 className="text-lg font-bold mb-3">Manage Matches</h2>
      <button className="mb-2 bg-green-700 text-white px-3 py-1 rounded" onClick={addMatch}>Add Match</button>
      <table className="w-full mb-6">
        <thead>
          <tr>
            <th>ID</th>
            <th>Teams</th>
            <th>Status</th>
            <th>Time</th>
            <th>Score</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {matches.map(m => (
            <tr key={m.id}>
              <td>{m.id}</td>
              <td>{m.home} vs {m.away}</td>
              <td>{m.status}</td>
              <td>{m.time}'</td>
              <td>{m.score[0]} - {m.score[1]}</td>
              <td>
                <button onClick={() => startEdit(m)} className="mr-2 text-blue-700">Edit</button>
                <button onClick={() => remove(m.id)} className="text-red-600">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {editing && (
        <div className="p-4 bg-gray-100 rounded">
          <h3>Edit Match #{editing.id}</h3>
          <input value={editing.home} onChange={e => setEditing(s => ({ ...s, home: e.target.value }))} className="border mx-2" />
          <input value={editing.away} onChange={e => setEditing(s => ({ ...s, away: e.target.value }))} className="border mx-2" />
          <input value={editing.score[0]} onChange={e => setEditing(s => ({ ...s, score: [parseInt(e.target.value), s.score[1]] }))} className="w-10 border mx-1" />
          -
          <input value={editing.score[1]} onChange={e => setEditing(s => ({ ...s, score: [s.score[0], parseInt(e.target.value)] }))} className="w-10 border mx-1" />
          <input value={editing.time} onChange={e => setEditing(s => ({ ...s, time: parseInt(e.target.value) }))} className="w-14 border mx-2" />
          <select value={editing.status} onChange={e => setEditing(s => ({ ...s, status: e.target.value }))}>
            <option>LIVE</option>
            <option>UPCOMING</option>
            <option>FINISHED</option>
          </select>
          <button className="bg-green-700 text-white px-3 py-1 rounded ml-2" onClick={saveEdit}>Save</button>
          <button className="ml-2" onClick={() => setEditing(null)}>Cancel</button>
        </div>
      )}
    </div>
  );
}