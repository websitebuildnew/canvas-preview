import { setToken, clearToken } from "./api";

export async function login(email, password) {
  const res = await fetch("http://localhost:4000/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  });
  const data = await res.json();
  if (data.token) {
    setToken(data.token);
    return data.user;
  } else {
    throw new Error(data.error || "Login failed");
  }
}

export async function getCurrentUser() {
  const token = localStorage.getItem("token");
  if (!token) return null;
  const res = await fetch("http://localhost:4000/auth/me", {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!res.ok) return null;
  return res.json();
}

export function logout() {
  clearToken();
}