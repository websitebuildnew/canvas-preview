import { useEffect, useRef } from "react";

export default function useWebSocket(url, onMessage) {
  const ws = useRef(null);
  useEffect(() => {
    ws.current = new window.WebSocket(url);
    ws.current.onmessage = e => {
      try {
        const msg = JSON.parse(e.data);
        onMessage && onMessage(msg);
      } catch {}
    };
    return () => ws.current && ws.current.close();
    // eslint-disable-next-line
  }, [url]);
  return ws.current;
}