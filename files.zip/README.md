# Sports Channel Live Streaming Web App

A full-featured, production-ready web app for live sports streaming, featuring:

- Secure authentication (JWT)
- Admin panel for channel/match management
- Real API integrations for matches/scores
- Live stream player with real-time canvas overlays
- Scalability for multiple sports/channels
- Social and YouTube integration

## Stack

- React + Tailwind CSS (frontend)
- React Router v6
- JWT authentication
- Backend API (mock or real RESTful)

## Setup

1. Install dependencies: `npm install`
2. Start: `npm start`
3. Configure API endpoints in `.env` or `src/config.js`

**Note:** Backend API, JWT token handling, and admin endpoints must be implemented server-side.