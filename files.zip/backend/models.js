// In-memory demo data. Replace with DB in production
exports.users = [
  { id: 1, email: "admin@sports.com", password: "admin123", isAdmin: true },
  { id: 2, email: "fan@sports.com", password: "fan123", isAdmin: false }
];

exports.matches = [
  {
    id: 1,
    home: "Team A",
    away: "Team B",
    score: [1, 0],
    time: 45,
    status: "LIVE",
    streamUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    poster: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=800&q=80"
  }
];