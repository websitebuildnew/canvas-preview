const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const { users } = require("./models");
const { SECRET } = require("./middleware");

// Login
router.post("/login", (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email && u.password === password);
  if (!user) return res.status(401).json({ error: "Invalid credentials" });
  const token = jwt.sign({ id: user.id, email: user.email, isAdmin: user.isAdmin }, SECRET, { expiresIn: "1d" });
  res.json({ token, user: { id: user.id, email: user.email, isAdmin: user.isAdmin } });
});

// Me
router.get("/me", (req, res) => {
  const header = req.headers.authorization;
  if (!header) return res.sendStatus(401);
  const token = header.split(" ")[1];
  try {
    const payload = jwt.verify(token, SECRET);
    const user = users.find(u => u.id === payload.id);
    if (!user) return res.sendStatus(401);
    res.json({ id: user.id, email: user.email, isAdmin: user.isAdmin });
  } catch {
    res.sendStatus(401);
  }
});

module.exports = router;