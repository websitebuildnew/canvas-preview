const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const WebSocket = require("ws");
const { authMiddleware } = require("./middleware");
const authRoutes = require("./auth");
const { users, matches } = require("./models");

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Auth routes
app.use("/auth", authRoutes);

// Public: Get all matches
app.get("/matches", (req, res) => res.json(matches));

// Public: Get a single match
app.get("/matches/:id", (req, res) => {
  const match = matches.find(m => m.id == req.params.id);
  if (!match) return res.sendStatus(404);
  res.json(match);
});

// Admin: Update match (score, time, status, etc.)
app.put("/matches/:id", authMiddleware, (req, res) => {
  if (!req.user.isAdmin) return res.sendStatus(403);
  const match = matches.find(m => m.id == req.params.id);
  if (!match) return res.sendStatus(404);
  Object.assign(match, req.body);
  // Broadcast update via WebSocket
  broadcastMatch(match);
  res.json(match);
});

// Admin: Add match
app.post("/matches", authMiddleware, (req, res) => {
  if (!req.user.isAdmin) return res.sendStatus(403);
  const newMatch = { id: matches.length + 1, ...req.body };
  matches.push(newMatch);
  res.json(newMatch);
});

// Admin: Remove match
app.delete("/matches/:id", authMiddleware, (req, res) => {
  if (!req.user.isAdmin) return res.sendStatus(403);
  const idx = matches.findIndex(m => m.id == req.params.id);
  if (idx === -1) return res.sendStatus(404);
  matches.splice(idx, 1);
  res.sendStatus(204);
});

// WebSocket for real-time match updates
const server = app.listen(4000, () => console.log("API running on http://localhost:4000"));
const wss = new WebSocket.Server({ server });

function broadcastMatch(match) {
  const message = JSON.stringify({ type: "MATCH_UPDATE", payload: match });
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN)
      client.send(message);
  });
}

// For admin: receive real-time updates and broadcast
wss.on("connection", ws => {
  ws.on("message", msg => {
    try {
      const { type, payload } = JSON.parse(msg);
      if (type === "ADMIN_UPDATE") {
        const match = matches.find(m => m.id == payload.id);
        if (match) {
          Object.assign(match, payload);
          broadcastMatch(match);
        }
      }
    } catch {}
  });
  // Send all current matches on connect
  ws.send(JSON.stringify({ type: "ALL_MATCHES", payload: matches }));
});